import { Album } from '../model/Album';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

//creating an array of albums 
export class AlbumService {

   albums: Album[]
   

  constructor(public http: HttpClient) {
    
 
    this.albums = []
  }

  

}
