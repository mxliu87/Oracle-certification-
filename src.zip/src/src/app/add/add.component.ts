import { AlbumService } from '../albums.service';
import { Album } from '../../model/Album';
import { Component, OnInit } from '@angular/core';
import { RouterModule, Routes, Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  newAlbum: Album
  successFlag: boolean

  constructor(public albumService: AlbumService, public router: Router) {
    this.newAlbum = new Album()
  
   
  }

  ngOnInit() {
  }

  //in this function we add the newly entered array from the user into the albums array
  addAlbum(addForm) {
  
    this.albumService.albums.push(this.newAlbum)
    console.log(this.albumService.albums)
    addForm.form.markAsPristine()
    this.newAlbum = new Album()

    //this enables the redirection of the list page after we add or save a new album
   
    this.router.navigateByUrl('/list')
  }

}
