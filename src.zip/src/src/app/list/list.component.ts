import { AlbumService } from '../albums.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  listId: number
  listTitle: string
  listArtist: string
  listPrice: number
  alertMsg: string;

  constructor(public albumsService: AlbumService) {
    this.listId = undefined
    this.listTitle = undefined
    this.listArtist = undefined
    this.listPrice = undefined
  }


//we are writing a function which will delte the desired element from the albums list
  deleteAlbum(i)
  {
    //we are using a confirmation alert box to delete the given album from the list
    var result = confirm("Are you sure you want to delete this album?")
    if(result)
     {
      this.albumsService.albums.splice(i, 1)
    }
  }

  ngOnInit() {

  }
}
