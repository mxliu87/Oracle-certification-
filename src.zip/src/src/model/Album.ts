export class Album {
    id: number
    title: string
    price: number
    artist: string

//here we are creating constructor for the class Album whose objects will have certain properties like id,title,price,artists

    constructor() {
        this.id = undefined
        this.title = ''
        this.price = undefined
        this.artist = ''
    }

}